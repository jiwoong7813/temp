var group__kvm__system__information =
[
    [ "kvmDeviceDiskSize", "group__kvm__system__information.html#ga048e19e67784886e40d567afcb210d4d", null ],
    [ "kvmDeviceFlashLeds", "group__kvm__system__information.html#ga318fb77a7dad0941a6d4bcf062acc028", null ],
    [ "kvmDeviceGetSerialNumber", "group__kvm__system__information.html#ga874407a10608e3ca4bc2b02b0f8641b6", null ],
    [ "kvmDeviceGetSoftwareInfo", "group__kvm__system__information.html#ga7767d720fe9d2b820915b85f29fe3f3e", null ],
    [ "kvmKmfGetUsage", "group__kvm__system__information.html#ga92de1e72f615e5ffa52e47b8e4b8fac5", null ]
];