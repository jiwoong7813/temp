var structkvm_log_rtc_clock_ex =
[
    [ "calendarTime", "structkvm_log_rtc_clock_ex.html#a144eaa57942f3e7ff88a173437737edf", null ],
    [ "timeStamp", "structkvm_log_rtc_clock_ex.html#aa1fa735b38f32cc201831ea72527ec37", null ]
];