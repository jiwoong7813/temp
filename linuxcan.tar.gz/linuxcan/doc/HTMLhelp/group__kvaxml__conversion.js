var group__kvaxml__conversion =
[
    [ "kvaBufferToXml", "group__kvaxml__conversion.html#ga873dd9799d37c23e5cb84d92bcda52df", null ],
    [ "kvaFileToXml", "group__kvaxml__conversion.html#gae8de06f7538a65ccb07df301ea663c50", null ],
    [ "kvaXmlDebugOutput", "group__kvaxml__conversion.html#gafe1b337165ebfa64edf379be0880ef26", null ],
    [ "kvaXmlGetErrorText", "group__kvaxml__conversion.html#gadb412c28b011db9ac7026a1f817dd7cc", null ],
    [ "kvaXmlToBuffer", "group__kvaxml__conversion.html#ga3e94f83e8f6bdd988f215dd7af7b1b64", null ],
    [ "kvaXmlToFile", "group__kvaxml__conversion.html#ga9c30a72338dd62a50015b852403a0f11", null ]
];