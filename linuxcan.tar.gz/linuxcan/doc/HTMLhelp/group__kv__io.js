var group__kv__io =
[
    [ "kvIoConfirmConfig", "group__kv__io.html#gaa50d734d29488bea72f5d3808835d7d9", null ],
    [ "kvIoGetNumberOfPins", "group__kv__io.html#ga0194114ea5bfcbf770d938b613ba87e6", null ],
    [ "kvIoPinGetAnalog", "group__kv__io.html#ga209b5932e8abf5e085c778d0dcac78ab", null ],
    [ "kvIoPinGetDigital", "group__kv__io.html#gaa5699336bbf78ddbe430dee8658ca7b3", null ],
    [ "kvIoPinGetInfo", "group__kv__io.html#ga851cb68946bf38686a065fccf11d6b42", null ],
    [ "kvIoPinGetOutputAnalog", "group__kv__io.html#ga78dd0cebc929d0c0d2b801943c6b0ddc", null ],
    [ "kvIoPinGetOutputDigital", "group__kv__io.html#gaaa8b56dd310525951aea002efa0d55ef", null ],
    [ "kvIoPinGetOutputRelay", "group__kv__io.html#ga26aaef6002a588a2ee56bdfc89a703df", null ],
    [ "kvIoPinSetAnalog", "group__kv__io.html#ga38a215ebc548b0d201fe805c5a8b3797", null ],
    [ "kvIoPinSetDigital", "group__kv__io.html#gad5a1f760ce49861c5970764024a732c7", null ],
    [ "kvIoPinSetInfo", "group__kv__io.html#ga88dda296acccff6acbc979a94b961188", null ],
    [ "kvIoPinSetRelay", "group__kv__io.html#gabb4bfa9d8f76d64065e03a9c95b7dace", null ]
];