var searchData=
[
  ['validation',['Validation',['../group__kvaxml__validation.html',1,'']]],
  ['virtual_20channels',['Virtual Channels',['../page_user_guide_virtual.html',1,'page_user_guide']]],
  ['ver',['ver',['../structkvm_log_event_ex.html#a98bf6dca6b83720d147fc6197143d631',1,'kvmLogEventEx']]]
];
