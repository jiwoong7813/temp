var structkvm_log_event_ex =
[
    [ "eventUnion", "structkvm_log_event_ex.html#a59fa82eb4479b9fcfce6198eae2031bf", null ],
    [ "msg", "structkvm_log_event_ex.html#ae3dbb7c786bd2bdd9d47bbaccbb17539", null ],
    [ "raw", "structkvm_log_event_ex.html#a2d78703fd9a85a4cb3ead816db9038bc", null ],
    [ "rtc", "structkvm_log_event_ex.html#a1f9964cb31c1515adcee1dc69c01d41b", null ],
    [ "trig", "structkvm_log_event_ex.html#a5ba860ad33a6d0976c7f2e0a8ed80bba", null ],
    [ "type", "structkvm_log_event_ex.html#af356674bbaaf9bb782af79059eef1346", null ],
    [ "ver", "structkvm_log_event_ex.html#a98bf6dca6b83720d147fc6197143d631", null ]
];